/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mohinhlopstaffnumber;

/**
 *
 * @author Win 8.1 Version 2
 */
public class Volunteer extends StaffNumber{

    @Override
    public int pay() {
       return 100;
    }
    
    
}
